from django.apps import AppConfig


class DjangoBootstrapv4SassConfig(AppConfig):
    name = 'django_bootstrapv4sass'
