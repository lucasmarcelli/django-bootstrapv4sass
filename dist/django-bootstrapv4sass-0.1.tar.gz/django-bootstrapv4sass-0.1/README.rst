=====
Django Bootstrap v4 Sass and JS
=====

Includes Jquery and Tether javascript as well.

Quick start
-----------

1. Add to installed apps

2. Set your `STATIC_ROOT` to `static/`

3. run `python manage.py collectstatic`. This will create a new directory called static at the project root.

4. Make a folder in the root static named after your app, and put your static files in this folder. You can also make it under your app directory but you'll need to run `python manage.py collectstatic` for every change.

5. Make a file in `static/` called `style.scss` or similar and do `@import "_sass/boostrap"` and then import your own sass files.

6. Run `sass style.scss:css/style.css`

7. Include `style.css` and everything in `js/` in your heads.
